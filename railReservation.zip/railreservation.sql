-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2022 at 05:09 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `railreservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `userID` int(11) NOT NULL,
  `phNo` decimal(10,0) NOT NULL,
  `userName` varchar(400) NOT NULL,
  `password` varchar(100) NOT NULL,
  `balance` float NOT NULL DEFAULT 0,
  `isAdmin` bit(1) NOT NULL DEFAULT b'0',
  `isActive` bit(1) NOT NULL DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`userID`, `phNo`, `userName`, `password`, `balance`, `isAdmin`, `isActive`) VALUES
(1, '9967151544', 'Abhishek Kolwankar', '123', 5300, b'1', b'1'),
(3, '9773879431', 'Salil Sanjay Gujar', '123', 0, b'0', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `reservationID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `trainID` int(11) NOT NULL,
  `seatsReserved` int(11) NOT NULL,
  `reservationStatus` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reservationID`, `userID`, `trainID`, `seatsReserved`, `reservationStatus`) VALUES
(3, 2, 1, 1, 0),
(4, 2, 1, 3, 0),
(5, 1, 1, 1, 2),
(6, 1, 2, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `train`
--

CREATE TABLE `train` (
  `trainID` int(11) NOT NULL,
  `trainName` varchar(200) NOT NULL,
  `departuretime` datetime NOT NULL,
  `startlocation` varchar(200) NOT NULL,
  `destinationlocation` varchar(200) NOT NULL,
  `seatCount` int(11) NOT NULL,
  `ticketPrice` float NOT NULL,
  `isDiscontinued` bit(1) NOT NULL DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `train`
--

INSERT INTO `train` (`trainID`, `trainName`, `departuretime`, `startlocation`, `destinationlocation`, `seatCount`, `ticketPrice`, `isDiscontinued`) VALUES
(1, 'Rajdhani Express', '2022-10-23 06:00:00', 'Mumbai', 'Delhi', 6, 1400, b'0'),
(2, 'Garibrath', '2022-10-27 17:00:00', 'Delhi', 'Mumbai', 10, 900, b'1'),
(3, 'Hero\'s Super Fast Train', '2022-12-15 23:00:00', 'Dara', 'Mumbai', 10, 220, b'1'),
(4, 'Hero Super Fast Train', '2022-12-20 23:00:00', 'dadar', 'thane', 10, 230, b'0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `passenger`
--
ALTER TABLE `passenger`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `phNo` (`phNo`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`reservationID`);

--
-- Indexes for table `train`
--
ALTER TABLE `train`
  ADD PRIMARY KEY (`trainID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `passenger`
--
ALTER TABLE `passenger`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `reservationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `train`
--
ALTER TABLE `train`
  MODIFY `trainID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

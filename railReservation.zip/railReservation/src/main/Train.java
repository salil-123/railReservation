/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package main;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author salil gujar
 */
public class Train extends javax.swing.JPanel {

    /**
     * Creates new form DisplayTrain
     */
    int userID;
    int isAdmin;
    String userName;
    int Balance;
    
    Connection con;
    public Train(Connection con) {
        initComponents();
        this.con=con;
    }
    
    public int getSelectedTrainID()
    {
        if (TrainDisplay.getSelectedRow()==-1)
            return -1;
        return (int) TrainDisplay.getValueAt(TrainDisplay.getSelectedRow(), 0);
    }
    public String getUserName()
    {
        return userName;
    }
    public int getBalance()
    {
        return Balance;
    }
    
    public void EventGoToLoginForm(ActionListener event) {
        LogoutBtn.addActionListener(event);
    }
    public void EventGoToReserveForm(ActionListener event) {
        BookTicketBtn.addActionListener(event);
    }
    public void EventGoToViewTicket(ActionListener event) {
        ViewTicketBtn.addActionListener(event);
    }
    public void EventGoToAddTrain(ActionListener event) {
        NewTrainBtn.addActionListener(event);
    }
    public void EventGoToEditTrain(ActionListener event) {
        EditTrainBtn.addActionListener(event);
    }
    
    void RefineSearch ()
    {
        String DateParameter=DateOfDeparture.getText();
        String FromParameter=FromLocation.getText();
        String ToParameter=ToLocation.getText();
        if("From Location".equals(FromParameter))
        {
            FromParameter="";
        }
        if("To Location".equals(ToParameter))
        {
            ToParameter="";
        }
        if(!DateOfDeparture.getText().matches("\\d{4}-\\d{2}-\\d{2}"))
        {
            DateParameter=LocalDate.now().toString();
        }
        PreparedStatement ps;
        try {
            DefaultTableModel TrainDisplayModel = (DefaultTableModel) TrainDisplay.getModel();
            TrainDisplayModel.setRowCount(0);
            
                    
            ps = con.prepareStatement("SELECT a.*,sum(b.seatsReserved) reservedSeats FROM Train a left join reservation b on a.trainID=b.trainID "
                    + "WHERE a.StartLocation like concat('%',?,'%') AND a.DestinationLocation like concat('%',?,'%') AND a.DepartureTime>=?  and a.isDiscontinued=0 and a.DepartureTime>=curdate()-1 "
                    + "group by a.trainID,a.trainName,a.departureTime,a.startLocation,a.destinationLocation,a.seatCount,ticketPrice,isDiscontinued "
                    + "order by a.DepartureTime");
            ps.setString(1, FromParameter);
            ps.setString(2, ToParameter);
            ps.setString(3, DateParameter);
            ResultSet result = ps.executeQuery();
            while(result.next()){
                TrainDisplayModel.addRow(new Object[] {
                    result.getInt(1),
                    result.getObject(2),
                    new SimpleDateFormat("dd-MMM-yy hh-mm a").format(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(result.getString(3))),
                    result.getObject(4),
                    result.getObject(5),
                    result.getInt(6)-result.getInt(9),
                    "Rs. "+String.valueOf(result.getObject(7)),
                    result.getString(9)});
            }
        } catch (SQLException | ParseException ex) {
            JOptionPane.showMessageDialog(null, "Search Error: "+ex);
        } 
    }
    
    public void Initialize(int userID)
    {
        PreparedStatement ps;
        try {
            ps = con.prepareStatement("SELECT userName,isAdmin,balance FROM Passenger WHERE userID=?");
            ps.setInt(1, userID);
            ResultSet result = ps.executeQuery();
            if(result.next()){
                this.userName=result.getString(1);
                this.isAdmin=result.getInt(2);
                this.Balance=result.getInt(3);
                this.userID=userID;
                UserLabel.setText("Hi, "+this.userName);
                RefineSearch();
                if(getTicketCount()==0)
                    ViewTicketBtn.setEnabled(false);
                else
                    ViewTicketBtn.setEnabled(true);
                if(this.isAdmin==0)
                    ManageBtn.setVisible(false); 
                NewTrainBtn.setVisible(false);
                EditTrainBtn.setVisible(false);
                backBtn.setVisible(false);
                DiscontinueTrain.setVisible(false);
                backBtn.doClick();
                checkNotification();
            }
            else{
                JOptionPane.showMessageDialog(null, "Initialization Failed.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: "+ex);
        }
    }
    
    int getTicketCount()
    {
    PreparedStatement ps;
    try {
        ps = con.prepareStatement("select count(*) ticketCount from reservation a join train b on a.trainid=b.trainid where a.userID=? and b.departuretime>=curdate()-1");
        ps.setInt(1, this.userID);
        ResultSet result = ps.executeQuery();
        if(result.next()){
            return result.getInt(1);
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error: "+ex);
    }
    return 0;
    }
    
    boolean DiscontinueTrain(int TrainID)
    {
        PreparedStatement ps;
        PreparedStatement ps1;
        PreparedStatement ps2;
        try {
            ps = con.prepareStatement("update reservation set reservationStatus=1 WHERE TrainID=?");
            ps.setInt(1, TrainID);
            ps.execute();
            ps1 = con.prepareStatement("update passenger u join reservation r on r.userid=u.userid join train t on t.trainid=r.trainid set balance=balance+(ticketprice*seatsreserved) WHERE t.TrainID=?");
            ps1.setInt(1, TrainID);
            ps1.execute();
            ps2 = con.prepareStatement("update train set isDiscontinued=1 WHERE TrainID=?");
            ps2.setInt(1, TrainID);
            ps2.execute();
            JOptionPane.showMessageDialog(null, "Train Discontinued, Reservations if any were reverted.");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: "+ex);
        } 
        return false;
    }
    
    void checkNotification()
    {
        PreparedStatement ps;
        PreparedStatement ps2;
        try {
            ps = con.prepareStatement("select count(*) notification from reservation a where a.userID=? and reservationStatus=1");
            ps.setInt(1, this.userID);
            ResultSet result = ps.executeQuery();
            if(result.next()){
                 if(result.getInt(1)>0) {
                    JOptionPane.showMessageDialog(null, "Alert: your Reserved train was canceled, balance was refunded");
                    ps2 = con.prepareStatement("update reservation set reservationStatus=2 where userID=? and reservationStatus=1");
                    ps2.setInt(1, this.userID);
                    ps2.execute();
                 }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: "+ex);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        FromLocation = new swing.MyTextField();
        ToLocation = new swing.MyTextField();
        DateOfDeparture = new swing.MyTextField();
        LogoutBtn = new swing.MyButton2();
        BookTicketBtn = new swing.MyButton2();
        ViewTicketBtn = new swing.MyButton2();
        EditTrainBtn = new swing.MyButton2();
        NewTrainBtn = new swing.MyButton2();
        ManageBtn = new swing.MyButton2();
        backBtn = new swing.MyButton2();
        DiscontinueTrain = new swing.MyButton2();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 0));
        jScrollPane1 = new javax.swing.JScrollPane();
        TrainDisplay = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        UserLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(125, 224, 237));

        FromLocation.setForeground(java.awt.Color.gray);
        FromLocation.setText("From Location");
        FromLocation.setMargin(new java.awt.Insets(2, 40, 2, 6));
        FromLocation.setPreferredSize(new java.awt.Dimension(80, 30));
        FromLocation.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                FromLocationFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                FromLocationFocusLost(evt);
            }
        });
        FromLocation.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                FromLocationKeyPressed(evt);
            }
        });

        ToLocation.setForeground(java.awt.Color.gray);
        ToLocation.setText("To Location");
        ToLocation.setMargin(new java.awt.Insets(2, 40, 2, 6));
        ToLocation.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                ToLocationFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                ToLocationFocusLost(evt);
            }
        });
        ToLocation.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ToLocationKeyPressed(evt);
            }
        });

        DateOfDeparture.setForeground(java.awt.Color.gray);
        DateOfDeparture.setText("Date of Departure");
        DateOfDeparture.setToolTipText("YYYY-MM-DD");
        DateOfDeparture.setMargin(new java.awt.Insets(2, 40, 2, 6));
        DateOfDeparture.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                DateOfDepartureFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                DateOfDepartureFocusLost(evt);
            }
        });
        DateOfDeparture.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                DateOfDepartureKeyPressed(evt);
            }
        });

        LogoutBtn.setBackground(new java.awt.Color(255, 255, 255));
        LogoutBtn.setText("Log Out");
        LogoutBtn.setColor(new java.awt.Color(255, 255, 255));
        LogoutBtn.setColorOver(new java.awt.Color(204, 204, 204));
        LogoutBtn.setMargin(new java.awt.Insets(2, 2, 3, 2));
        LogoutBtn.setPreferredSize(new java.awt.Dimension(70, 30));

        BookTicketBtn.setBackground(new java.awt.Color(255, 255, 255));
        BookTicketBtn.setText("Book Ticket");
        BookTicketBtn.setColor(new java.awt.Color(255, 255, 255));
        BookTicketBtn.setColorOver(new java.awt.Color(204, 204, 204));
        BookTicketBtn.setMargin(new java.awt.Insets(2, 2, 3, 2));

        ViewTicketBtn.setBackground(new java.awt.Color(255, 255, 255));
        ViewTicketBtn.setText("View Ticket");
        ViewTicketBtn.setColor(new java.awt.Color(255, 255, 255));
        ViewTicketBtn.setColorOver(new java.awt.Color(204, 204, 204));
        ViewTicketBtn.setMargin(new java.awt.Insets(2, 2, 3, 2));
        ViewTicketBtn.setMaximumSize(new java.awt.Dimension(100, 23));
        ViewTicketBtn.setMinimumSize(new java.awt.Dimension(100, 23));

        EditTrainBtn.setBackground(new java.awt.Color(255, 255, 255));
        EditTrainBtn.setText("Edit Train");
        EditTrainBtn.setColor(new java.awt.Color(255, 255, 255));
        EditTrainBtn.setColorOver(new java.awt.Color(204, 204, 204));
        EditTrainBtn.setMargin(new java.awt.Insets(2, 2, 3, 2));
        EditTrainBtn.setMaximumSize(new java.awt.Dimension(100, 23));
        EditTrainBtn.setMinimumSize(new java.awt.Dimension(100, 23));

        NewTrainBtn.setBackground(new java.awt.Color(255, 255, 255));
        NewTrainBtn.setText("New Train");
        NewTrainBtn.setColor(new java.awt.Color(255, 255, 255));
        NewTrainBtn.setColorOver(new java.awt.Color(204, 204, 204));
        NewTrainBtn.setMargin(new java.awt.Insets(2, 2, 3, 2));
        NewTrainBtn.setMaximumSize(new java.awt.Dimension(100, 23));
        NewTrainBtn.setMinimumSize(new java.awt.Dimension(100, 23));

        ManageBtn.setBackground(new java.awt.Color(255, 255, 255));
        ManageBtn.setText("Manage");
        ManageBtn.setColor(new java.awt.Color(255, 255, 255));
        ManageBtn.setColorOver(new java.awt.Color(204, 204, 204));
        ManageBtn.setMargin(new java.awt.Insets(2, 2, 3, 2));
        ManageBtn.setMaximumSize(new java.awt.Dimension(100, 23));
        ManageBtn.setMinimumSize(new java.awt.Dimension(100, 23));
        ManageBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManageBtnActionPerformed(evt);
            }
        });

        backBtn.setBackground(new java.awt.Color(255, 255, 255));
        backBtn.setText("Back");
        backBtn.setColor(new java.awt.Color(255, 255, 255));
        backBtn.setColorOver(new java.awt.Color(204, 204, 204));
        backBtn.setMargin(new java.awt.Insets(2, 2, 3, 2));
        backBtn.setMaximumSize(new java.awt.Dimension(100, 23));
        backBtn.setMinimumSize(new java.awt.Dimension(100, 23));
        backBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtnActionPerformed(evt);
            }
        });

        DiscontinueTrain.setBackground(new java.awt.Color(255, 255, 255));
        DiscontinueTrain.setText("Drop Train");
        DiscontinueTrain.setColor(new java.awt.Color(255, 255, 255));
        DiscontinueTrain.setColorOver(new java.awt.Color(204, 204, 204));
        DiscontinueTrain.setMargin(new java.awt.Insets(2, 2, 3, 2));
        DiscontinueTrain.setMaximumSize(new java.awt.Dimension(100, 23));
        DiscontinueTrain.setMinimumSize(new java.awt.Dimension(100, 23));
        DiscontinueTrain.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DiscontinueTrainActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FromLocation, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ToLocation, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DateOfDeparture, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addComponent(backBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ManageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(NewTrainBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(EditTrainBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DiscontinueTrain, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ViewTicketBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BookTicketBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LogoutBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, 6, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(FromLocation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(ToLocation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(DateOfDeparture, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(LogoutBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(BookTicketBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(ViewTicketBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(DiscontinueTrain, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(EditTrainBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(NewTrainBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(ManageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(backBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TrainDisplay.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, "a", "d", "b", "c",  new Integer(33), "    Rs. 15.0", null},
                {null, "e", "h", "f", "g",  new Integer(12), "    Rs. 15.0", null},
                {null, "i", "l", "j", "k",  new Integer(1), "    Rs. 25.0", null}
            },
            new String [] {
                "TrainID", "Train Name", "Departure Time", "From Location", "To Location", "Seats Left", "Ticket Price", "Reserved"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TrainDisplay.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        TrainDisplay.setFillsViewportHeight(true);
        TrainDisplay.setGridColor(new java.awt.Color(204, 204, 204));
        TrainDisplay.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        TrainDisplay.setShowHorizontalLines(true);
        TrainDisplay.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(TrainDisplay);
        TrainDisplay.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (TrainDisplay.getColumnModel().getColumnCount() > 0) {
            TrainDisplay.getColumnModel().getColumn(0).setMinWidth(0);
            TrainDisplay.getColumnModel().getColumn(0).setPreferredWidth(0);
            TrainDisplay.getColumnModel().getColumn(0).setMaxWidth(0);
            TrainDisplay.getColumnModel().getColumn(1).setResizable(false);
            TrainDisplay.getColumnModel().getColumn(1).setPreferredWidth(150);
            TrainDisplay.getColumnModel().getColumn(2).setResizable(false);
            TrainDisplay.getColumnModel().getColumn(2).setPreferredWidth(110);
            TrainDisplay.getColumnModel().getColumn(3).setResizable(false);
            TrainDisplay.getColumnModel().getColumn(3).setPreferredWidth(110);
            TrainDisplay.getColumnModel().getColumn(4).setResizable(false);
            TrainDisplay.getColumnModel().getColumn(4).setPreferredWidth(100);
            TrainDisplay.getColumnModel().getColumn(5).setMinWidth(75);
            TrainDisplay.getColumnModel().getColumn(5).setPreferredWidth(75);
            TrainDisplay.getColumnModel().getColumn(5).setMaxWidth(75);
            TrainDisplay.getColumnModel().getColumn(6).setMinWidth(85);
            TrainDisplay.getColumnModel().getColumn(6).setPreferredWidth(85);
            TrainDisplay.getColumnModel().getColumn(6).setMaxWidth(85);
            TrainDisplay.getColumnModel().getColumn(7).setMinWidth(0);
            TrainDisplay.getColumnModel().getColumn(7).setPreferredWidth(0);
            TrainDisplay.getColumnModel().getColumn(7).setMaxWidth(70);
        }

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("SansSerif", 1, 45)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(125, 224, 237));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Photos/railReservation.png"))); // NOI18N
        jLabel2.setPreferredSize(new java.awt.Dimension(300, 70));

        UserLabel.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        UserLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        UserLabel.setText("Hi, Salil Gujar");

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Connecting the World Since 1857");
        jLabel3.setPreferredSize(new java.awt.Dimension(300, 70));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("SansSerif", 1, 45)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("RailReservation");
        jLabel4.setPreferredSize(new java.awt.Dimension(300, 70));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Salil Gujar & Team");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("This Application is Created By");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 354, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 576, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(UserLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(UserLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel5)
                        .addGap(1, 1, 1)))
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void FromLocationFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_FromLocationFocusGained
        if (FromLocation.getText().equals("From Location")) {
            FromLocation.setText("");
            FromLocation.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_FromLocationFocusGained

    private void FromLocationFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_FromLocationFocusLost
        if (FromLocation.getText().isEmpty()) {
            FromLocation.setText("From Location");
            FromLocation.setForeground(Color.GRAY);
        }
        RefineSearch();
    }//GEN-LAST:event_FromLocationFocusLost

    private void ToLocationFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_ToLocationFocusGained
        if (ToLocation.getText().equals("To Location")) {
            ToLocation.setText("");
            ToLocation.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_ToLocationFocusGained

    private void ToLocationFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_ToLocationFocusLost
        if (ToLocation.getText().isEmpty()) {
            ToLocation.setText("To Location");
            ToLocation.setForeground(Color.GRAY);
        }
        RefineSearch();
    }//GEN-LAST:event_ToLocationFocusLost

    private void DateOfDepartureFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_DateOfDepartureFocusGained
        if (DateOfDeparture.getText().equals("Date of Departure")) {
            DateOfDeparture.setText("");
            DateOfDeparture.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_DateOfDepartureFocusGained

    private void DateOfDepartureFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_DateOfDepartureFocusLost
        if (DateOfDeparture.getText().isEmpty()) {
            DateOfDeparture.setText("Date of Departure");
            DateOfDeparture.setForeground(Color.GRAY);
        }
        RefineSearch();
    }//GEN-LAST:event_DateOfDepartureFocusLost

    private void ManageBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManageBtnActionPerformed
        ManageBtn.setVisible(false);
        NewTrainBtn.setVisible(true);
        EditTrainBtn.setVisible(true);
        DiscontinueTrain.setVisible(true);
        backBtn.setVisible(true);
        backBtn.setVisible(true);
        ViewTicketBtn.setVisible(false);
        BookTicketBtn.setVisible(false);
        LogoutBtn.setVisible(false);
        TrainDisplay.requestFocus();
        TrainDisplay.getColumnModel().getColumn(7).setPreferredWidth(70);
    }//GEN-LAST:event_ManageBtnActionPerformed

    private void backBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtnActionPerformed
        ManageBtn.setVisible(true);
        NewTrainBtn.setVisible(false);
        EditTrainBtn.setVisible(false);
        DiscontinueTrain.setVisible(false);
        backBtn.setVisible(false);
        ViewTicketBtn.setVisible(true);
        BookTicketBtn.setVisible(true);
        LogoutBtn.setVisible(true);
        TrainDisplay.requestFocus();
        TrainDisplay.getColumnModel().getColumn(7).setPreferredWidth(0);
    }//GEN-LAST:event_backBtnActionPerformed

    private void DateOfDepartureKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_DateOfDepartureKeyPressed
        if(evt.getKeyCode()==10)
            TrainDisplay.requestFocus();
    }//GEN-LAST:event_DateOfDepartureKeyPressed

    private void ToLocationKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ToLocationKeyPressed
        if(evt.getKeyCode()==10)
            TrainDisplay.requestFocus();
    }//GEN-LAST:event_ToLocationKeyPressed

    private void FromLocationKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_FromLocationKeyPressed
        if(evt.getKeyCode()==10)
            TrainDisplay.requestFocus();
    }//GEN-LAST:event_FromLocationKeyPressed

    private void DiscontinueTrainActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DiscontinueTrainActionPerformed
        if(getSelectedTrainID()==-1)
            JOptionPane.showMessageDialog(null, "Please Select a Train from the List");
        else if (DiscontinueTrain(getSelectedTrainID())){
            RefineSearch();
        }
    }//GEN-LAST:event_DiscontinueTrainActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private swing.MyButton2 BookTicketBtn;
    private swing.MyTextField DateOfDeparture;
    private swing.MyButton2 DiscontinueTrain;
    private swing.MyButton2 EditTrainBtn;
    private swing.MyTextField FromLocation;
    private swing.MyButton2 LogoutBtn;
    private swing.MyButton2 ManageBtn;
    private swing.MyButton2 NewTrainBtn;
    private swing.MyTextField ToLocation;
    private javax.swing.JTable TrainDisplay;
    private javax.swing.JLabel UserLabel;
    private swing.MyButton2 ViewTicketBtn;
    private swing.MyButton2 backBtn;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}

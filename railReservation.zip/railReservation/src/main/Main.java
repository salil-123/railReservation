/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author SALIL
 */
public class Main extends javax.swing.JFrame {
    //variables
    int userID;
    Connection con=null;
    
    public Main() {
        initComponents();
        setSize(Toolkit.getDefaultToolkit().getScreenSize());
        try {
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/railReservation", "root", "");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "SQL Connection Error: "+ex);
            System.exit(0);
        }
        
        Login login = new Login(con);
        Register register = new Register(con);
        Train Train = new Train(con);
        Reserve Reserve=new Reserve(con);
        Ticket Ticket=new Ticket(con);
        ManageTrain ManageTrain=new ManageTrain(con);
        slide.setAnimate(10);
        slide.init(login, register,Train,Reserve,Ticket,ManageTrain);
        

        //events sliders
        login.EventGoToRegisterForm((ActionEvent ae) -> {
            switchTo(385,520,1,false);
            register.Initialize();
        });
        register.EventGOToLoginForm((ActionEvent ae) -> {
            switchTo(385,520,0,true);
            login.Initialize();
        });
        Train.EventGoToLoginForm((ActionEvent ae) -> {
            userID=0;
            switchTo(385,520,0,true);
            login.Initialize();
        });
        Train.EventGoToReserveForm((ActionEvent ae) -> {
            if(Train.getSelectedTrainID()==-1)
                JOptionPane.showMessageDialog(null, "Please Select a Train from the List");
            else
            {
                Reserve.Initialize(userID, Train.getSelectedTrainID(), Train.getUserName(),Train.getBalance());
                switchTo(385,630,3,true);
            }
        });
        login.EventUserLogin((ActionEvent ae) -> {
            userID=login.userLogin();
            if (userID>0) {
                switchTo(799,520,2,false);
                Train.Initialize(userID);
            }
        });
        register.EventRegisterUser((ActionEvent ae) -> {
            userID=register.userRegister();
            switchTo(799,520,2,false);
            Train.Initialize(userID);
        });
        Reserve.EventGoToTrainPage((ActionEvent ae) -> {
            switchTo(799,520,2,false);
            Train.Initialize(userID);
        });
        Reserve.EventReserveTicket((ActionEvent ae) -> {
            if(Reserve.ReserveTicket()) {
                switchTo(799,520,2,false);
                Train.Initialize(userID);
            }
        });
        Train.EventGoToViewTicket((ActionEvent ae) -> {
            switchTo(700,310,4,true);
            Ticket.Initialize(userID);
        });
        Ticket.EventGoToTrainPage((ActionEvent ae) -> {
            switchTo(799,520,2,false);
            Train.Initialize(userID);
        });
        ManageTrain.EventGoToTrainPage((ActionEvent ae) -> {
            switchTo(799,520,2,false);
            Train.Initialize(userID);
        });
        ManageTrain.EventSubmitDetails((ActionEvent ae) -> {
            if(ManageTrain.getTrainID()==0) {
                if(ManageTrain.InsertTrain())
                {
                    switchTo(799,520,2,false);
                    Train.Initialize(userID);
                }
            } else {
                if(ManageTrain.UpdateTrain())
                {
                    switchTo(799,520,2,false);
                    Train.Initialize(userID);
                }}
        });
        Train.EventGoToAddTrain((ActionEvent ae) -> {
            switchTo(385,520,5,true);
            ManageTrain.Initialize(userID);
        });
        Train.EventGoToEditTrain((ActionEvent ae) -> {
            if(Train.getSelectedTrainID()==-1)
                JOptionPane.showMessageDialog(null, "Please Select a Train from the List");
            else {
                ManageTrain.Initialize(userID,Train.getSelectedTrainID());
             switchTo(385,520,5,true);
            }
        });
        Ticket.EventCancelTicket((ActionEvent ae) -> {
            if(Ticket.CancelTicket()) {
                switchTo(799,520,2,false);
                Train.Initialize(userID);
            }
        });
                
    }
    
    void switchTo(int Width,int Height,int index,boolean animateRight)
    {
        int panelWidth=Width+12;
        int panelHeight=Height+12;
        panelBorder1.setSize(new Dimension(panelWidth, panelHeight));
        slide.setPreferredSize(new Dimension(Width, Height));
        slide.setSize(new Dimension(Width, Height));
        slide.show(index,animateRight);
        panelBorder1.setLocation((panelBorder1.getParent().getWidth()-panelBorder1.getWidth())/2, (panelBorder1.getParent().getHeight()-panelBorder1.getHeight())/2);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelGradiente1 = new swing.PanelGradiente();
        panelBorder1 = new swing.PanelBorder();
        slide = new swing.PanelSlide();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        panelGradiente1.setBackground(new java.awt.Color(255, 255, 255));
        panelGradiente1.setColorPrimario(new java.awt.Color(146, 233, 251));
        panelGradiente1.setColorSecundario(new java.awt.Color(12, 137, 163));

        panelBorder1.setBackground(new java.awt.Color(255, 255, 255));

        slide.setBackground(new java.awt.Color(255, 255, 255));
        slide.setPreferredSize(new java.awt.Dimension(385, 520));

        javax.swing.GroupLayout slideLayout = new javax.swing.GroupLayout(slide);
        slide.setLayout(slideLayout);
        slideLayout.setHorizontalGroup(
            slideLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 385, Short.MAX_VALUE)
        );
        slideLayout.setVerticalGroup(
            slideLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 520, Short.MAX_VALUE)
        );

        panelBorder1.setLayer(slide, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout panelBorder1Layout = new javax.swing.GroupLayout(panelBorder1);
        panelBorder1.setLayout(panelBorder1Layout);
        panelBorder1Layout.setHorizontalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(slide, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelBorder1Layout.setVerticalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(slide, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelGradiente1.setLayer(panelBorder1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout panelGradiente1Layout = new javax.swing.GroupLayout(panelGradiente1);
        panelGradiente1.setLayout(panelGradiente1Layout);
        panelGradiente1Layout.setHorizontalGroup(
            panelGradiente1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGradiente1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panelBorder1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelGradiente1Layout.setVerticalGroup(
            panelGradiente1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGradiente1Layout.createSequentialGroup()
                .addContainerGap(94, Short.MAX_VALUE)
                .addComponent(panelBorder1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(94, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelGradiente1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelGradiente1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Main().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private swing.PanelBorder panelBorder1;
    private swing.PanelGradiente panelGradiente1;
    private swing.PanelSlide slide;
    // End of variables declaration//GEN-END:variables
}

package main;



import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */

/**
 *
 * @author salil gujar
 */
public class ManageTrain extends javax.swing.JPanel {

    Connection con;
    int UserID;
    int TrainID;
    int Reservations;
    Date DepartureOriginalTime;
    
    public ManageTrain(Connection con) {
        initComponents();
        this.con=con;
    }
    
    public void EventGoToTrainPage(ActionListener event) {
        returnBtn.addActionListener(event);
    }
    public void EventSubmitDetails(ActionListener event) {
        SubmitBtn.addActionListener(event);
    }
    
    public int getTrainID()
    {
        return TrainID;
    }

    public boolean InsertTrain()
    {
        PreparedStatement ps;
        try {
            int totalSeat = Integer.parseInt(totalSeats.getText());
            int totalPrice = Integer.parseInt(pricePerSeat.getText());
                        
            String departTime = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss").format(new SimpleDateFormat("dd-MMM-yyyy hh:mm aa").parse(departuretime.getText()));
            
            System.out.println(departTime);
            ps = con.prepareStatement("insert into train(trainName,departureTime,startLocation,destinationLocation,seatCount,ticketPrice) values (?,?,?,?,?,?)");
            ps.setString(1, trainName.getText());
            ps.setString(2, departTime);
            ps.setString(3, fromLocation.getText());
            ps.setString(4, toLocation.getText());
            ps.setInt(5, totalSeat);
            ps.setInt(6, totalPrice);
            ps.execute();
            JOptionPane.showMessageDialog(null, "Train Added Successsfully");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: "+ex);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Validation Error, totalSeats and pricePerSeat must be integers");
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Validation Error, invalid Date format : eg. 24-Jan-2022 11:00 am");
        }
        return false;
    }
    
    public boolean UpdateTrain()
    {
        PreparedStatement ps;
        try {
            int totalSeat = Integer.parseInt(totalSeats.getText());
            int totalPrice = Integer.parseInt(pricePerSeat.getText());
            String departTime = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss").format(new SimpleDateFormat("dd-MMM-yyyy hh:mm a").parse(departuretime.getText()));

            
            int hourDifference=(int) (this.DepartureOriginalTime.getTime() - new SimpleDateFormat("dd-MMM-yyyy hh:mm a").parse(departuretime.getText()).getTime())/ 3600000;
            
            if(this.Reservations>0) {
                if(hourDifference<0 && hourDifference>24) {
                    JOptionPane.showMessageDialog(null, "Train can only be delayed by max 24 hours.");
                    return false;
                }
                if(totalSeat<this.Reservations) {
                    JOptionPane.showMessageDialog(null, "Total seats must be higher than reserved Seats.");
                    return false;
                }
                ps = con.prepareStatement("update train set trainName=?, departureTime=?, seatCount=? where trainID=?");
                ps.setInt(4, this.TrainID);
            }
            else {
                ps = con.prepareStatement("update train set trainName=?, departureTime=?, seatCount=?, destinationLocation=?, startLocation=?, ticketPrice=? where trainID=?");
                ps.setString(4, toLocation.getText());
                ps.setString(5, fromLocation.getText());
                ps.setInt(6, totalPrice);  
                ps.setInt(7, this.TrainID);
            }
            ps.setString(1, trainName.getText());
            ps.setString(2, departTime);
            ps.setInt(3, totalSeat);
            ps.execute();
            JOptionPane.showMessageDialog(null, "Train Updated Successsfully");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: "+ex);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Validation Error, totalSeats and pricePerSeat must be integers");
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Validation Error, invalid Date format : eg. 24-Jan-2022 11:00 am");
        }
        return false;
    }
    
    public void Initialize(int UserID)
    {
        this.UserID=UserID;
        this.TrainID=0;
        headerLabel.setText("New Train");
        fromLocation.setEnabled(true);
        toLocation.setEnabled(true);
        pricePerSeat.setEnabled(true);
        reservedSeats.setText("0");
        trainName.setText("");
        fromLocation.setText("");
        toLocation.setText("");
        departuretime.setText("");
        totalSeats.setText("");
        pricePerSeat.setText("");
    }
    
    public void Initialize(int UserID,int TrainID)
    {
        this.UserID=UserID;
        this.TrainID=TrainID;
        headerLabel.setText("Edit Train");
        
        PreparedStatement ps;
        try {
            ps = con.prepareStatement("SELECT a.*,sum(b.seatsReserved) reservedSeats FROM Train a left join reservation b on a.trainID=b.trainID WHERE a.TrainID=? "
                    + "group by a.trainID,a.trainName,a.departureTime,a.startLocation,a.destinationLocation,a.seatCount,ticketPrice,isDiscontinued");
            ps.setInt(1, this.TrainID);
            ResultSet result = ps.executeQuery();
            if(result.next())
            {
                trainName.setText(result.getString(2));
                fromLocation.setText(result.getString(4));
                toLocation.setText(result.getString(5));
                this.DepartureOriginalTime=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(result.getString(3));
                departuretime.setText(new SimpleDateFormat("dd-MMM-yyyy hh:mm a").format(DepartureOriginalTime));
                totalSeats.setText(String.valueOf(result.getInt(6)));
                this.Reservations=result.getInt(9);
                reservedSeats.setText(String.valueOf(this.Reservations));
                pricePerSeat.setText(String.valueOf(result.getInt(7)));
                
                if(this.Reservations>0) {
                    fromLocation.setEnabled(false);
                    toLocation.setEnabled(false);
                    pricePerSeat.setEnabled(false);
                }
            }
            else{
                JOptionPane.showMessageDialog(null, "Initialization Failed.");
            }
        } catch (SQLException|ParseException ex) {
            JOptionPane.showMessageDialog(null, "Error: "+ex);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        trainName = new swing.MyTextField();
        jLabel1 = new javax.swing.JLabel();
        headerLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        fromLocation = new swing.MyTextField();
        toLocation = new swing.MyTextField();
        returnBtn = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        departuretime = new swing.MyTextField();
        totalSeats = new swing.MyTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        pricePerSeat = new swing.MyTextField();
        reservedSeats = new swing.MyTextField();
        SubmitBtn = new swing.MyButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(385, 520));

        trainName.setFocusCycleRoot(true);
        trainName.setNextFocusableComponent(fromLocation);

        jLabel1.setText("Train Name");

        headerLabel.setFont(new java.awt.Font("sansserif", 1, 48)); // NOI18N
        headerLabel.setForeground(new java.awt.Color(69, 68, 68));
        headerLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        headerLabel.setText("Edit Train");

        jLabel3.setText("From Location");

        jLabel4.setText("To Location");

        fromLocation.setNextFocusableComponent(toLocation);
        fromLocation.setOpaque(true);

        toLocation.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        toLocation.setNextFocusableComponent(departuretime);

        returnBtn.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        returnBtn.setForeground(new java.awt.Color(30, 122, 236));
        returnBtn.setContentAreaFilled(false);
        returnBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        returnBtn.setLabel("Cancel");

        jLabel5.setText("Depart Datetime");

        jLabel6.setText("Total Seats");

        departuretime.setToolTipText("dd-mmm-yyyy hh:mm am/pm");
        departuretime.setNextFocusableComponent(totalSeats);

        totalSeats.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        totalSeats.setToolTipText("");
        totalSeats.setNextFocusableComponent(pricePerSeat);

        jLabel7.setText("Cost per Seat");

        jLabel8.setText("Reserved Seats");

        pricePerSeat.setToolTipText("");

        reservedSeats.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        reservedSeats.setEnabled(false);

        SubmitBtn.setBackground(new java.awt.Color(125, 229, 251));
        SubmitBtn.setForeground(new java.awt.Color(40, 40, 40));
        SubmitBtn.setText("Submit");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(returnBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(headerLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(fromLocation, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(toLocation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(departuretime, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(totalSeats, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel8))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(pricePerSeat, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(reservedSeats, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(SubmitBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(trainName, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(65, 65, 65))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(headerLabel)
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(trainName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fromLocation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(toLocation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(departuretime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(totalSeats, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pricePerSeat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reservedSeats, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(SubmitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
                .addComponent(returnBtn)
                .addGap(30, 30, 30))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private swing.MyButton SubmitBtn;
    private swing.MyTextField departuretime;
    private swing.MyTextField fromLocation;
    private javax.swing.JLabel headerLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private swing.MyTextField pricePerSeat;
    private swing.MyTextField reservedSeats;
    private javax.swing.JButton returnBtn;
    private swing.MyTextField toLocation;
    private swing.MyTextField totalSeats;
    private swing.MyTextField trainName;
    // End of variables declaration//GEN-END:variables
}
